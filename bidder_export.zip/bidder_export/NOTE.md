# BIDDER + ACM-Champernowne export

Drop-in bundle of the ACM-Champernowne core and the BIDDER block
generator, plus two demo scripts. Both modules are independent — you
can take just `core/` or just `generator/` if you only need one.

## Contents

    core/
        acm_core.py     # Python: n-primes, Champernowne reals, first-digit utils
        acm_core.c/.h   # C twin (standalone, links with -lm)
    generator/
        bidder.py       # Python: BIDDER block generator (Speck32/64 + Feistel)
        bidder.c/.h     # C twin (standalone, SHA-256 inlined)
        speck.py        # Optional: full Speck family (all 10 variants).
                        # bidder.py does NOT import this — only take it if
                        # you want the broader cipher table or test vectors.
    contamination.py    # Demo: BIDDER uniform source under add/mul chains
    mult_blur.py        # Demo: cartesian + polar shutter views, in one figure

## Fix-ups on the receiving end

1. **Python import path.** The `.py` files import each other by bare
   name (`from acm_core import ...`, `from bidder import Bidder`). You
   need `core/` and `generator/` on `sys.path`. Pick one:
   - keep `core/` and `generator/` as siblings of the demo scripts and
     let the scripts insert paths via `__file__` (the way `mult_blur.py`
     does it out of the box), or
   - drop both `.py` files into a single package directory and import
     with the package prefix, or
   - put them at repo root.

2. **`contamination.py` paths.** This file is copied verbatim from the
   BIDDER experiments tree, so its `sys.path.insert(...)` calls walk up
   four `..` to find `core/` and `generator/`. Adjust those two lines to
   match wherever you place the modules in the new project.

3. **C build.** Both translation units are standalone — no extra objects
   to link.

       cc -O2 -c core/acm_core.c -o acm_core.o -lm
       cc -O2 -c generator/bidder.c -o bidder.o

   `acm_core.c` needs `-lm`. `bidder.c` does not.

4. **numpy / sage.** `acm_core.py` imports numpy at module top. Run any
   script that touches it under `sage -python`, not plain `python3`.
   `bidder.py` has no numpy dependency and runs under either.

5. **Plot style.** The demo scripts use the BIDDER house palette
   (`#0a0a0a` background, white text, inferno colormap). Strip or
   replace if you want a different look.
