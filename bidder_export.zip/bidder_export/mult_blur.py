"""
mult_blur.py — Combined cartesian + polar shutter views.

Merges shutter_dual.py (cartesian heatmaps) and shutter_polar.py
(polar disc warps) into a single figure. Computes the addition and
multiplication first-digit heatmaps once, then renders both views in
a 2x2 grid:

    +-----------------+-----------------+
    | Addition        | Multiplication  |   cartesian heatmaps
    +-----------------+-----------------+
    | Addition disc   | Mul disc        |   polar warps of same data
    +-----------------+-----------------+

The addition pane shows the rolling shutter (diagonal stripes that
become spiral arms in the polar view). The multiplication pane shows
rapid Benford convergence (a static gradient that becomes concentric
rings).

Expects `core/acm_core.py` to be importable. By default this script
inserts a sibling `core/` directory onto sys.path; adjust if your
layout differs.
"""

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, 'core'))

import numpy as np
import matplotlib.pyplot as plt
from acm_core import acm_champernowne_array, acm_first_digit_array


# ---------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------

N = 10000          # number of n-Champernowne reals to draw from
n_steps = 500      # rows of the heatmap (operation count, 1..n_steps)
n_samples = 8000   # trials per row
SEED = 42


# ---------------------------------------------------------------------------
# Build the two heatmaps (shared between cartesian and polar panes)
# ---------------------------------------------------------------------------

reals = acm_champernowne_array(N)
log_reals = np.log10(reals)
rng_add = np.random.default_rng(SEED)
rng_mul = np.random.default_rng(SEED)


def first_digits_from_log_fracs(fracs):
    return np.minimum((10**fracs + 1e-9).astype(int), 9)


print("Building addition heatmap...")
heat_add = np.zeros((n_steps, 9))
for i, k in enumerate(range(1, n_steps + 1)):
    indices = rng_add.integers(0, N, size=(n_samples, k))
    sums = np.sum(reals[indices], axis=1)
    fds = acm_first_digit_array(sums)
    for d in range(1, 10):
        heat_add[i, d - 1] = np.sum(fds == d) / n_samples
    if (i + 1) % 50 == 0:
        print(f"  add step {i+1}/{n_steps}")

print("Building multiplication heatmap...")
heat_mul = np.zeros((n_steps, 9))
for i, k in enumerate(range(1, n_steps + 1)):
    indices = rng_mul.integers(0, N, size=(n_samples, k))
    log_products = np.sum(log_reals[indices], axis=1)
    fracs = log_products - np.floor(log_products)
    fds = first_digits_from_log_fracs(fracs)
    for d in range(1, 10):
        heat_mul[i, d - 1] = np.sum(fds == d) / n_samples
    if (i + 1) % 50 == 0:
        print(f"  mul step {i+1}/{n_steps}")


# ---------------------------------------------------------------------------
# Polar warp (from shutter_polar.py)
# ---------------------------------------------------------------------------

def warp_heatmap_to_polar(heat, img_size=1800):
    """Warp a (n_steps x 9) heatmap into a polar disc.

    Radius = row index (operation count). Center = 1, edge = n_steps.
    Angle  = column index (digit 1-9). Each digit gets 2*pi/9 radians.
    """
    cx, cy = img_size / 2, img_size / 2
    r_max = img_size / 2 - 20
    r_min = r_max * 0.02

    iy, ix = np.mgrid[0:img_size, 0:img_size]
    dx = (ix - cx).astype(np.float64)
    dy = (iy - cy).astype(np.float64)
    r = np.sqrt(dx * dx + dy * dy)
    theta = np.arctan2(dy, dx) % (2 * np.pi)

    row_idx = ((r - r_min) / (r_max - r_min) * heat.shape[0]).astype(int)
    theta_shifted = (theta + np.pi / 2) % (2 * np.pi)
    col_idx = (theta_shifted / (2 * np.pi) * 9).astype(int)

    valid = (r >= r_min) & (r <= r_max) & \
            (row_idx >= 0) & (row_idx < heat.shape[0]) & \
            (col_idx >= 0) & (col_idx < 9)

    img = np.zeros((img_size, img_size))
    img[valid] = heat[row_idx[valid], col_idx[valid]]
    return img


print("Warping to polar...")
img_add = warp_heatmap_to_polar(heat_add)
img_mul = warp_heatmap_to_polar(heat_mul)


# ---------------------------------------------------------------------------
# Plot: 2x2 — cartesian on top, polar on bottom
# ---------------------------------------------------------------------------

print("Plotting...")
vmax = max(heat_add.max(), heat_mul.max())

fig = plt.figure(figsize=(20, 22))
fig.patch.set_facecolor('#0a0a0a')

gs = fig.add_gridspec(2, 2, height_ratios=[1.0, 1.1],
                      hspace=0.10, wspace=0.06)

# --- Top row: cartesian heatmaps ---
ax_add = fig.add_subplot(gs[0, 0])
ax_mul = fig.add_subplot(gs[0, 1], sharey=ax_add)

for ax, heat, title in [(ax_add, heat_add, 'Addition'),
                        (ax_mul, heat_mul, 'Multiplication')]:
    ax.set_facecolor('#0a0a0a')
    ax.imshow(heat, aspect='auto', cmap='inferno',
              interpolation='bilinear', origin='lower',
              extent=[0.5, 9.5, 1, n_steps],
              vmin=0, vmax=vmax)
    ax.set_xticks(range(1, 10))
    ax.set_xlabel('first digit', color='white', fontsize=13)
    ax.set_title(title, color='white', fontsize=16, pad=12)
    ax.tick_params(colors='white')

ax_add.set_ylabel('number of operations', color='white', fontsize=13)
plt.setp(ax_mul.get_yticklabels(), visible=False)

# --- Bottom row: polar warps ---
ax_add_p = fig.add_subplot(gs[1, 0])
ax_mul_p = fig.add_subplot(gs[1, 1])

for ax, img in [(ax_add_p, img_add), (ax_mul_p, img_mul)]:
    ax.set_facecolor('#0a0a0a')
    ax.imshow(img, cmap='inferno', interpolation='bilinear',
              origin='lower', vmin=0, vmax=vmax)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)

plt.savefig('mult_blur.png', dpi=200,
            facecolor='#0a0a0a', bbox_inches='tight')
print("-> mult_blur.png")
